#!/bin/sh

mkdir /etc/config/save.mmbx
cp /etc/config/mmpbx* /etc/config/save.mmbx/
cp /tmp/run/mountd/sda1/setup/voip/mmpbx /etc/config/
cp /tmp/run/mountd/sda1/setup/voip/mmpbxbrcmcountry /etc/config/
/etc/init.d/mmpbxd restart


