#!/bin/sh

########## LEGGERE PRIMA IL FILE README ###########


###  TOGLIERE '#' DAVANTI AL COMANDO CHE INTERESSA

### ITALIANIZZA LA GUI - FACOLTATIVO

#cp -pidRv /tmp/run/mountd/sda1/setup/lang /www/lang

### INSTALLA SFTP SERVER PER L'USO DI FILEZILLA O DEL FILE MANAGER DEL DESKTOP DI LINUX - FACOLTATIVO

#opkg install /tmp/run/mountd/sda1/setup/sftp/openssh-sftp-server_7.1p2-1_brcm63xx-tch.ipk

### INSTALLA NANO COME EDITOR - FACOLTATIVO

#opkg install /tmp/run/mountd/sda1/setup/nano/*

### CONFIGURAZIONE DEL WIFI: RISOLVE IL PROBLEMA DEL WIFI GUEST - EDITARE CON I PROPRI DATI - OCCORRE IL RAVVIO - FACOLTATIVO

#cp /etc/config/wireless /etc/config/wireless.save & cp /tmp/run/mountd/sda1/setup/wifi/wireless /etc/config/wireless

### PERMETTE LA VISUALIZZAZIONE DELLO STATO DEL WIFI GUEST NELLA GUI - FACOLTATICO

#cp /www/cards/004_wireless.lp /www/cards/004_wireless.lp.save & cp /tmp/run/mountd/sda1/setup/wifi/004_wireless.lp /www/cards/ & /etc/init.d/nginx restart

### INSTALLA I FILE MMBX PER PER I PROVIDER ITALIANI PER AVERE IL SEGNALE DI LIBERO E OCCUPATO CORRETTO
### TIM  

#sh  /tmp/run/mountd/sda1/setup/voip/tim.sh

### TISCALI

#sh  /tmp/run/mountd/sda1/setup/voip/tiscali.sh

 
