#!/bin/sh

###  TOGLIERE '#' DAVANTI AL COMANDO CHE INTERESSA PER IL RIPRISTINO

###  TOGLIERE LA TRADUZIONE ITALIANA

#rm -r /www/lang

### RIMUOVERE SFTP SERVER

#opkg remove openssh-sftp-server

### RIMOVERE NANO E LE SUE DIPENDENZE

#opkg remove nano libncurses terminfo

###  RIPRISTINARE LA CONFIGURAZIONE DEL DEL WIFI ORIGINALE - RICHIEDE IL RIAVVIO

#mv /etc/config/wireless.save /etc/config/wireless 

### RIPRISTINARE LA VISUALIZZAZIONE DELLO STATO DEL WIFI ORIGINALE 

#mv /www/cards/004_wireless.lp.save /www/cards/004_wireless.lp  & /etc/init.d/nginx restart

### RIPRISTINA FILE MMBX 
### TIM  

#cp /etc/config/save.mmbx/mmpbx /etc/config/ & cp /etc/config/save.mmbx/mmpbxbrcmcountry /etc/config/ & rm -r /etc/config/save.mmbx

### TISCALI

#cp /etc/config/save.mmbx/* /etc/config/ & rm -r /etc/config/save.mmbx

 
